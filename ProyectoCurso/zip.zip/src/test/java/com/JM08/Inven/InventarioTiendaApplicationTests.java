package com.JM08.Inven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioTiendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
