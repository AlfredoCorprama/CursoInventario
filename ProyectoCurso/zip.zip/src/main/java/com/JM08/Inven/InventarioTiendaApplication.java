package com.JM08.Inven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioTiendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventarioTiendaApplication.class, args);
	}

}
